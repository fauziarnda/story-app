import StoryModel from '../../api/story-model.js';

export default class HomePresenter {
  constructor(view) {
    this.view = view;
  }

  async loadStories() {
    try {
      const stories = await StoryModel.getAllStories({ location: 1 });
      this.view.showStories(stories);
    } catch (error) {
      this.view.showError('Gagal memuat cerita: ' + error.message);
    }
  }

  async addStory({ description, photo }) {
    try {
      await StoryModel.addNewStory({ description, photo });

      this.view.onStoryPostedSuccess('Cerita berhasil dibagikan!');
      const [newStory] = await StoryModel.getAllStories({
        page: 1,
        size: 1,
        location: 1,
      });
      this.view.addStoryToFeed(newStory);
    } catch (error) {
      this.view.showError('Gagal mengirim cerita: ' + error.message);
    }
  }
}
