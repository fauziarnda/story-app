import App from "./app.js";
import "../styles/styles.css";
import "./pages/addStory/add-story.css";

function updateNavbarVisibility() {
  const navbar = document.getElementById("navbar");
  const token = localStorage.getItem("token");

  if (!token) {
    navbar.style.display = "none";
    navbar.setAttribute("aria-hidden", "true");
  } else {
    navbar.style.display = "flex";
    navbar.removeAttribute("aria-hidden");
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  updateNavbarVisibility();

  const content = document.querySelector("#content");
  const app = new App({ content });
  await app.renderPage();

  window.addEventListener("hashchange", async () => {
    await app.renderPage();
    updateNavbarVisibility();
  });
});
