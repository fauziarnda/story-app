import { getActiveRoute } from "./routes/url-parser.js";
import routes from "./routes/routes.js";

export default class App {
  #content;
  #onAuthChange;

  constructor({ content, onAuthChange }) {
    this.#content = content;
    this.#onAuthChange = onAuthChange;
  }

  async renderPage() {
    const routeName = getActiveRoute();

    if (routeName === "/" && localStorage.getItem("token")) {
      window.location.hash = "#/home";
      return;
    }

    const route = routes[routeName];

    const page = route();

    if (document.startViewTransition) {
      await document.startViewTransition(async () => {
        this.#content.innerHTML = await page.render();
        await page.afterRender?.();
      });
    } else {
      this.#content.innerHTML = await page.render();
      await page.afterRender?.();
    }

    if (typeof this.#onAuthChange === "function") {
      this.#onAuthChange();
    }
  }
}
